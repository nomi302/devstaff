package com.devstaff.farmcollector.controller;

import com.devstaff.farmcollector.model.PlantedEntity;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.reactive.server.WebTestClient;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWebTestClient
public class PlantedControllerTest {

    @Autowired
    private WebTestClient webTestClient;

    @Test
    public void testAddPlantedData() {
        PlantedEntity plantedData = new PlantedEntity();
        plantedData.setFarmName("TestFarm");
        plantedData.setPlantingArea(10.0);
        plantedData.setCropType("TestCrop");
        plantedData.setExpectedAmount(5.0);

        webTestClient.post()
                .uri("/api/planted")
                .contentType(MediaType.APPLICATION_JSON)
                .bodyValue(plantedData)
                .exchange()
                .expectStatus().isOk();
    }
}
