package com.devstaff.farmcollector;

public class FarmCollectorApplicationTests {
}
