package com.devstaff.farmcollector.controller;

public class HarvestedControllerTest {
}
