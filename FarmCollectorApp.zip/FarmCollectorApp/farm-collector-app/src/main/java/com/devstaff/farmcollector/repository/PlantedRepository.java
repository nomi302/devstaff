package com.devstaff.farmcollector.repository;

import com.devstaff.farmcollector.model.PlantedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface PlantedRepository extends JpaRepository<PlantedEntity, Long> {
    List<PlantedEntity> findByFarmNameAndCropType(String farmName, String cropType);
}
