package com.devstaff.farmcollector.repository;

import com.devstaff.farmcollector.model.HarvestedEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface HarvestedRepository extends JpaRepository<HarvestedEntity, Long> {
    List<HarvestedEntity> findByFarmNameAndCropType(String farmName, String cropType);
}
