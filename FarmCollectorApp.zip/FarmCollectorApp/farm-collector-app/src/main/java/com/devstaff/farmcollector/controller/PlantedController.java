package com.devstaff.farmcollector.controller;

import com.devstaff.farmcollector.model.PlantedEntity;
import com.devstaff.farmcollector.repository.PlantedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/planted")
public class PlantedController {
    @Autowired
    private PlantedRepository plantedRepository;

    @PostMapping
    public ResponseEntity<String> addPlantedData(@RequestBody PlantedEntity plantedData) {
        plantedRepository.saveAndFlush(plantedData);
        return ResponseEntity.ok("Planted data added successfully");
    }
}
