package com.devstaff.farmcollector.controller;


import com.devstaff.farmcollector.repository.HarvestedRepository;
import com.devstaff.farmcollector.repository.PlantedRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/reports")
public class ReportsController {
    @Autowired
    private PlantedRepository plantedRepository;

    @Autowired
    private HarvestedRepository harvestedRepository;

    @GetMapping("/farm/{farmName}")
    public ResponseEntity<String> getReportByFarm(@PathVariable String farmName) {
        // Logic to calculate and return the report for the specified farm
        // (e.g., by aggregating planted and harvested data)
        // Return the report as a plain text string
        return ResponseEntity.ok("Report for Farm: " + farmName);
    }

    @GetMapping("/crop/{cropType}")
    public ResponseEntity<String> getReportByCrop(@PathVariable String cropType) {
        // Logic to calculate and return the report for the specified crop type
        // Return the report as a plain text string
        return ResponseEntity.ok("Report for Crop Type: " + cropType);
    }
}
