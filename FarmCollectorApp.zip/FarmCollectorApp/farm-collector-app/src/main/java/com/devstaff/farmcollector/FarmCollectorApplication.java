package com.devstaff.farmcollector;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.WebApplicationInitializer;


/*@EnableTransactionManagement
@EnableScheduling
@EnableAsync
@EnableCaching
@EnableAspectJAutoProxy(proxyTargetClass = true)*/
@SpringBootApplication
public class FarmCollectorApplication extends SpringBootServletInitializer implements WebApplicationInitializer {

    private static final Logger logger = LoggerFactory.getLogger(FarmCollectorApplication.class);

    public static void main(String[] args) throws Exception {
        SpringApplication.run(FarmCollectorApplication.class, args);
        logger.debug("-- Application Started --");
    }
}
